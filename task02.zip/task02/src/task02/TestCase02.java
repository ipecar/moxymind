package task02;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.util.Scanner;

import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import org.testng.Assert;



public class TestCase02 {
	public static <OuputStream> void main(String[] args) throws InterruptedException, IOException {
		//WebDriver driver;
		//System.setProperty("webdriver,gecko.driver", "/home/administrator/.cache/selenium/geckodriver/linux64/0.36.0/geckodriver");
	
	    File myObj = new File("data.txt");
	      Scanner myReader = new Scanner(myObj);
	      String data = null ;
	      while (myReader.hasNextLine()) {
	        data = myReader.nextLine();
	        System.out.println(data);
	      }
	      myReader.close();
	      long startTime = System.currentTimeMillis();
		  HttpClient client = HttpClient.newHttpClient() ;

		        HttpRequest request = HttpRequest.newBuilder()
		                .uri(URI.create("https://reqres.in/api/users"))
		                .header("x-api-key", "reqres-free-v1")
		                .POST(HttpRequest.BodyPublishers.ofString(data))
		                .build();
		        HttpResponse<String> response = client.send(request,
		                HttpResponse.BodyHandlers.ofString());

		   long endTime = System.currentTimeMillis();
		   long totalTime = endTime - startTime;
		   long  limit = 10000 ;
		        System.out.println(response.body());
		        System.out.println("status code:" + response.statusCode());
		        String dataout= response.body();
		        int status = response.statusCode();
		        int expStatus = 201;
		        Assert.assertEquals(status, expStatus, "assert fails");
		        Assert.assertEquals(dataout, response.body(),"assert fails");
		       if(totalTime<limit)
		       {
		        System.out.println("Total Page Load Time: " + totalTime + "milliseconds");
		       }
		       else
		       {
		    	   System.out.println("error total time above limit");
		       }
		        
}
}
