package task02;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.devtools.DevTools;


import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;

@SuppressWarnings("unused")
public class TestCase1 {
	
	
	public static <OuputStream> void main(String[] args) throws InterruptedException, IOException {
		WebDriver driver;
		System.setProperty("webdriver,gecko.driver", "/home/administrator/.cache/selenium/geckodriver/linux64/0.36.0/geckodriver");
		driver = new FirefoxDriver();
	
	
		URL url = URI.create("https://reqres.in/api/users" ).toURL();
		
		 // Open a connection(?) on the URL(??) and cast the response(???)
		 URLConnection connection = /*(HttpURLConnection)*/ url.openConnection();

		 // Now it's "open", we can set the request method, headers etc.
		 connection.setRequestProperty("x-api-key", "reqres-free-v1");
		 connection.setRequestProperty("accept", "application/json");
		 // This line makes the request
		 InputStream responseStream = connection.getInputStream();
		  
	        BufferedReader in = new BufferedReader(new InputStreamReader(
	        		connection.getInputStream()));
	        String inputLine;
	        while ((inputLine = in.readLine()) != null) 
	        {
	        System.out.println(inputLine);
	        
	        }
	        
	        driver.get("https://reqres.in/api/users");
			
	   			 WebElement total = driver.findElement(By.xpath("//*[@id=\"/total\"]"));
	   			 String totalText = total.getText();
	   			 String expectedTotal ="total 12";
	   			 Assert.assertEquals(expectedTotal, totalText,"assertion of total failed" );
	   			 System.out.println(totalText);
	   			 WebElement LN0 = driver.findElement(By.xpath("//*[@id=\"/data/0/last_name\"]"));
	   			 String LN0Text = LN0.getText();
	   			 String LN0TextExp = "last_name \"Bluth\"" ;
	   			Assert.assertEquals(LN0Text, LN0TextExp,"assertion of last name of first user failed" );
	   			 System.out.println(LN0Text);
	   			 WebElement LN1 = driver.findElement(By.xpath("//*[@id=\"/data/1/last_name\"]"));
	   			 String LN1Text = LN1.getText();
	   			 String LN1TextExp = "last_name \"Weaver\"";
	   			Assert.assertEquals(LN1Text, LN1TextExp,"assertion of last name of second user failed " );
	   			 System.out.println(LN1Text);	   			   			     
	   				 
	   		
	   			URL url2 = URI.create("https://reqres.in/api/users?page=2" ).toURL();
	   	 

		 
		 HttpURLConnection connection2 = (HttpURLConnection) url2.openConnection();

		 // Now it's "open", we can set the request method, headers etc.
		 connection2.setRequestProperty("x-api-key", "reqres-free-v1");
		 connection2.setRequestProperty("accept", "application/json");
		 // This line makes the request
		 InputStream responseStream2 = connection2.getInputStream();
		 
		  
	        BufferedReader in2 = new BufferedReader(new InputStreamReader(
	        		connection2.getInputStream()));
	        String inputLine2;
	        while ((inputLine2 = in2.readLine()) != null) 
	        {
	            System.out.println(inputLine2);	          
	            
	        }
	        
	   

}
	}
