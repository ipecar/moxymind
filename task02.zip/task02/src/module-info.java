/**
 * 
 */
/**
 * 
 */
module task02 {
	requires org.seleniumhq.selenium.api;
	requires org.seleniumhq.selenium.firefox_driver;
	requires com.fasterxml.jackson.databind;
	requires com.fasterxml.jackson.core;
	requires org.seleniumhq.selenium.remote_driver;
	requires org.seleniumhq.selenium.devtools_v138;
	requires org.seleniumhq.selenium.devtools_v136;
	requires java.net.http;
	requires org.testng;
	
}